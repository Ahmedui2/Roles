const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ButtonBuilder } = require('discord.js');
const { isBotOwner, isAdminOrAuthorized } = require('../utils/permissions');
const { customRoles, saveData } = require('../utils/data');

module.exports = {
  name: 'settings',
  description: 'عرض قائمة إعدادات البوت',
  execute: async (message) => {
    if (!isBotOwner(message.author.id) && !isAdminOrAuthorized(message.member)) {
      return message.reply('**ليس لديك صلاحية استخدام هذا الأمر**');
    }

    const embed = new EmbedBuilder()
      .setTitle('اختر الإعداد')
      .setDescription('اختر من القائمة التالية الإعداد الذي تريد تعديله')
      .setColor(0x0099ff);

    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('settings_select')
        .setPlaceholder('اختر الإعداد')
        .addOptions([
          {
            label: 'إعداد البوت',
            description: 'تغيير اسم، صورة، حالة، وبنر البوت',
            value: 'bot_settings',
          },
          {
            label: 'إدارة الرولات',
            description: 'التحكم بجميع الرولات الخاصة',
            value: 'manage_roles',
          },
          {
            label: 'إضافة رول خاص',
            description: 'إضافة رول خاص جديد',
            value: 'add_custom_role',
          },
          {
            label: 'إدارة المصرحين',
            description: 'إضافة أو إزالة المصرحين',
            value: 'manage_authorized',
          },
          {
            label: 'صلاحيات الرولات',
            description: 'تعيين صلاحيات الرولات الافتراضية',
            value: 'set_role_permissions',
          },
          {
            label: 'الخروج من السيرفر',
            description: 'إخراج البوت من السيرفر',
            value: 'leave_server',
          },
        ])
    );

    await message.reply({ embeds: [embed], components: [row], flags: [1 << 6] });
  },

  handleInteraction: async (interaction) => {
    if (!isBotOwner(interaction.user.id) && !isAdminOrAuthorized(interaction.member)) {
      return interaction.reply({
        content: '**ليس لديك صلاحية استخدام هذا الأمر**',
        ephemeral: true,
      });
    }

    if (interaction.customId === 'edit_selected_roles') {
      const selectedRoles = interaction.message.components[0].components[0].options
        .filter((option) => option.default)
        .map((option) => option.value);

      if (selectedRoles.length === 0) {
        await interaction.reply({
          content: '**يجب اختيار رول واحد على الأقل**',
          ephemeral: true,
        });
        return;
      }

      const editRow = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('edit_roles_option')
          .setPlaceholder('اختر نوع التعديل')
          .addOptions([
            {
              label: 'تغيير الاسم',
              description: 'تغيير اسم الرولات المحددة',
              value: 'edit_name',
            },
            {
              label: 'تغيير اللون',
              description: 'تغيير لون الرولات المحددة',
              value: 'edit_color',
            },
            {
              label: 'تغيير الإيموجي',
              description: 'تغيير إيموجي الرولات المحددة',
              value: 'edit_emoji',
            },
            {
              label: 'تعديل الصلاحيات',
              description: 'تعديل صلاحيات الرولات المحددة',
              value: 'edit_permissions',
            },
            {
              label: 'تغيير المالك',
              description: 'تغيير مالك الرولات المحددة',
              value: 'edit_owner',
            }
          ])
      );

      await interaction.update({
        content: '**اختر نوع التعديل الذي تريد تطبيقه على الرولات المحددة**',
        components: [editRow],
      });
      return;
    } else if (interaction.customId === 'delete_selected_roles') {
      const selectedRoles = interaction.message.components[0].components[0].options
        .filter((option) => option.default)
        .map((option) => option.value);

      if (selectedRoles.length === 0) {
        await interaction.reply({
          content: '**يجب اختيار رول واحد على الأقل**',
          ephemeral: true,
        });
        return;
      }

      const confirmRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('confirm_delete_roles')
          .setLabel('تأكيد الحذف')
          .setStyle(4),
        new ButtonBuilder()
          .setCustomId('cancel_delete_roles')
          .setLabel('إلغاء')
          .setStyle(2)
      );

      await interaction.update({
        content: `**هل أنت متأكد من حذف ${selectedRoles.length} رول؟**`,
        components: [confirmRow],
      });
      return;
    } else if (interaction.customId === 'confirm_delete_roles') {
      const selectedRoles = interaction.message.components[0].components[0].options
        .filter((option) => option.default)
        .map((option) => option.value);

      try {
        let deletedCount = 0;
        for (const roleId of selectedRoles) {
          const role = interaction.guild.roles.cache.get(roleId);
          if (role) {
            // Notify bot.js about authorized deletion
            const { authorizeRoleDeletion } = require('../bot');
            authorizeRoleDeletion(roleId, interaction.user.id);

            await role.delete('تم الحذف من خلال إعدادات البوت');
            if (customRoles[interaction.guildId] && customRoles[interaction.guildId][roleId]) {
              delete customRoles[interaction.guildId][roleId];
              deletedCount++;
            }
          }
        }
        
        // حفظ التغييرات في قاعدة البيانات
        saveData();

        await interaction.update({
          content: `**تم حذف ${deletedCount} رول بنجاح**`,
          components: [],
        });
      } catch (error) {
        console.error('Error deleting roles:', error);
        await interaction.update({
          content: '**حدث خطأ أثناء حذف الرولات**',
          components: [],
        });
      }
      return;
    } else if (interaction.customId === 'cancel_delete_roles') {
      await interaction.update({
        content: '**تم إلغاء عملية الحذف**',
        components: [],
      });
      return;
    } else if (interaction.customId === 'settings_select') {
      const choice = interaction.values[0];

      if (choice === 'manage_roles') {
        const guildRoles = customRoles[interaction.guildId] || {};
        const roles = Object.entries(guildRoles)
          .map(([roleId, roleData]) => {
            const role = interaction.guild.roles.cache.get(roleId);
            if (!role) {
              // إذا لم يتم العثور على الرول في السيرفر، نحذفه من قاعدة البيانات
              delete guildRoles[roleId];
              return null;
            }
            return {
              role,
              owner: roleData.ownerId,
              data: roleData,
            };
          })
          .filter((r) => r !== null);

        // حفظ التغييرات بعد حذف الرولات غير الموجودة
        if (Object.keys(guildRoles).length === 0) {
          delete customRoles[interaction.guildId];
        }
        saveData();

        if (roles.length === 0) {
          return interaction.reply({
            content: '**لا توجد رولات خاصة في السيرفر**',
            ephemeral: true,
          });
        }

        const row = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('roles_select')
            .setPlaceholder('اختر الرولات')
            .setMinValues(1)
            .setMaxValues(roles.length)
            .addOptions(
              roles.map(({ role, owner }) => ({
                label: role.name,
                description:
                  `المالك: ${interaction.guild.members.cache.get(owner)?.user.username || 'غير معروف'}`,
                value: role.id,
              }))
            )
        );

        const buttons = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('select_all_roles')
            .setLabel('اختيار الكل')
            .setStyle(1),
          new ButtonBuilder()
            .setCustomId('edit_selected_roles')
            .setLabel('تعديل')
            .setStyle(3)
            .setDisabled(true),
          new ButtonBuilder()
            .setCustomId('delete_selected_roles')
            .setLabel('حذف')
            .setStyle(4)
            .setDisabled(true)
        );

        const embed = new EmbedBuilder()
          .setTitle('إدارة الرولات الخاصة')
          .setDescription('اختر الرولات التي تريد إدارتها')
          .setColor(0x0099ff);

        await interaction.reply({
          embeds: [embed],
          components: [row, buttons],
          ephemeral: true,
        });
      } else if (choice === 'bot_settings') {
        const modal = new ModalBuilder()
          .setCustomId('bot_settings_modal')
          .setTitle('إعدادات البوت');

        const botNameInput = new TextInputBuilder()
          .setCustomId('bot_name')
          .setLabel('اسم البوت')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('أدخل اسم البوت الجديد')
          .setRequired(false);

        const botAvatarInput = new TextInputBuilder()
          .setCustomId('bot_avatar')
          .setLabel('رابط صورة البوت')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('أدخل رابط صورة البوت الجديدة')
          .setRequired(false);

        const botBannerInput = new TextInputBuilder()
          .setCustomId('bot_banner')
          .setLabel('رابط بنر البوت')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('أدخل رابط بنر البوت الجديد')
          .setRequired(false);

        const botStatusInput = new TextInputBuilder()
          .setCustomId('bot_status')
          .setLabel('حالة البوت')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('مثال: online, idle, dnd')
          .setRequired(false);

        const botActivityInput = new TextInputBuilder()
          .setCustomId('bot_activity')
          .setLabel('نشاط البوت')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('مثال للستريمنق: twitch.tv/username\nمثال للواتشنق: اسم اللعبة')
          .setRequired(false);

        const firstRow = new ActionRowBuilder().addComponents(botNameInput);
        const secondRow = new ActionRowBuilder().addComponents(botAvatarInput);
        const thirdRow = new ActionRowBuilder().addComponents(botBannerInput);
        const fourthRow = new ActionRowBuilder().addComponents(botStatusInput);
        const fifthRow = new ActionRowBuilder().addComponents(botActivityInput);

        modal.addComponents(firstRow, secondRow, thirdRow, fourthRow, fifthRow);
        await interaction.showModal(modal);
      }
    }
  }
};
